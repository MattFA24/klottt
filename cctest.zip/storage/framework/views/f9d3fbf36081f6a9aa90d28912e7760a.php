<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You for Contacting Us</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { width: 90%; max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; }
        .header { background-color: #784ba0; color: white; padding: 10px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { padding: 20px; }
        .quote { background-color: #f9f9f9; border-left: 4px solid #784ba0; margin: 20px 0; padding: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>We've Received Your Message!</h2>
        </div>
        <div class="content">
            <p>Hello <strong><?php echo e($data['name']); ?></strong>,</p>
            <p>Thank you for reaching out to us. We have successfully received your message and will get back to you as soon as possible.</p>
            <p>Here is a copy of your message for your records:</p>
            <div class="quote">
                <p><strong>Subject:</strong> <?php echo e($data['subject']); ?></p>
                <p><strong>Message:</strong><br><?php echo e($data['message']); ?></p>
            </div>
            <p>Best regards,<br>The Team</p>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\matth\Herd\cloudcomputingtest\resources\views/registration.blade.php ENDPATH**/ ?>